#region Using

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

using Gizmox.WebGUI.Common;
using Gizmox.WebGUI.Forms;
using RT2008.DAL;
using System.Data.SqlClient;

#endregion

namespace RT2008.PriceMgmt.Reports
{
    public partial class History : Form
    {
        public History()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.Text += " Reports [ " + ReportType.ToString() + " ]";
            FillComboList();
        }

        #region Fill Combo List
        private void FillComboList()
        {
            FillFromList();
            FillToList();
        }

        private void FillFromList()
        {
            string type = this.ReportType.ToString().Substring(0, 1);

            PriceManagementActiveHeader.LoadCombo(ref cboFrom, "TxNumber", false, false, string.Empty, "PM_TYPE ='" + type + "'");
        }

        private void FillToList()
        {
            string type = this.ReportType.ToString().Substring(0, 1);

            PriceManagementActiveHeader.LoadCombo(ref cboTo, "TxNumber", false, false, string.Empty, "PM_TYPE ='" + type + "'");

            this.cboTo.SelectedIndex = cboTo.Items.Count - 1;
        }
        #endregion

        #region BindData To Report
        private DataTable BindData()
        {
            string sql = @"
SELECT TOP 100 PERCENT * 
FROM vwRptActivePriceMgmt
WHERE TxNumber BETWEEN '" + this.cboFrom.Text.Trim() + "' AND '" + this.cboTo.Text.Trim() + @"'
AND CONVERT(NVARCHAR(10),EffectDate,126) BETWEEN '" + this.dtpTxDateFrom.Value.ToString("yyyy-MM-dd") + @"'
                                             AND '" + this.dtpTxDateTo.Value.ToString("yyyy-MM-dd") + @"'
";
            if (this.ReportType.ToString().Substring(0, 1) == "P")
            {
                sql += " AND PM_TYPE = 'P'";
            }
            else if (this.ReportType.ToString().Substring(0, 1) == "D")
            {
                sql += " AND PM_TYPE = 'D'";
            }
            
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = sql;
            cmd.CommandTimeout = Common.Config.CommandTimeout;
            cmd.CommandType = CommandType.Text;

            using (DataSet dataset = SqlHelper.Default.ExecuteDataSet(cmd))
            {
                return dataset.Tables[0];
            }
        }
        #endregion

        #region Validate Selections
        private bool IsSelValid()
        {
            bool result = true;
            if (string.Compare(this.cboFrom.Text.Trim(), this.cboTo.Text.Trim()) > 0)
            {
                result = false;
                MessageBox.Show("Range Error: Tx Number", "Message");
            }
            else if (this.dtpTxDateFrom.Value > this.dtpTxDateTo.Value)
            {
                result = false;
                MessageBox.Show("Range Error: Tx Date", "Message");
            }
            return result;
        }
        #endregion

        private PriceUtility.PriceMgmtType reportType = PriceUtility.PriceMgmtType.Price;
        public PriceUtility.PriceMgmtType ReportType
        {
            get
            {
                return reportType;
            }
            set
            {
                reportType = value;
            }
        }

        private void btnPriview_Click(object sender, EventArgs e)
        {
            if (IsSelValid())
            {
                string[,] param = { 
                {"FromTxNumber",this.cboFrom.Text.Trim()},
                {"ToTxNumber",this.cboTo.Text.Trim()},
                {"FromTxDate", this.dtpTxDateFrom.Value.ToString(RT2008.SystemInfo.Settings.GetDateFormat())},
                {"ToTxDate", this.dtpTxDateTo.Value.ToString(RT2008.SystemInfo.Settings.GetDateFormat())},
                {"PrintedOn", DateTime.Now.ToString(RT2008.SystemInfo.Settings.GetDateTimeFormat())},
                {"DateFormat", RT2008.SystemInfo.Settings.GetDateFormat()},
                {"STKCODE",RT2008.SystemInfo.Settings.GetSystemLabelByKey("STKCODE")},
                {"APPENDIX1",RT2008.SystemInfo.Settings.GetSystemLabelByKey("APPENDIX1")},
                {"APPENDIX2",RT2008.SystemInfo.Settings.GetSystemLabelByKey("APPENDIX2")},
                {"APPENDIX3",RT2008.SystemInfo.Settings.GetSystemLabelByKey("APPENDIX3")},
                {"CLASS1",RT2008.SystemInfo.Settings.GetSystemLabelByKey("CLASS1")},
                {"CLASS2",RT2008.SystemInfo.Settings.GetSystemLabelByKey("CLASS2")},
                {"CLASS3",RT2008.SystemInfo.Settings.GetSystemLabelByKey("CLASS3")},
                {"CLASS4",RT2008.SystemInfo.Settings.GetSystemLabelByKey("CLASS4")},
                {"CLASS5",RT2008.SystemInfo.Settings.GetSystemLabelByKey("CLASS5")},
                {"CLASS6",RT2008.SystemInfo.Settings.GetSystemLabelByKey("CLASS6")},
                {"CompanyName",RT2008.SystemInfo.CurrentInfo.Default.CompanyName}
                };

                RT2008.Controls.Reporting.Viewer view = new RT2008.Controls.Reporting.Viewer();

                view.Datasource = BindData();
                view.ReportDatasourceName = "RT2008_Controls_Reporting_DataSource4PriceMgmt_vwRptActivePriceMgmt";

                if (this.ReportType.ToString().Substring(0, 1) == "P")
                {
                    view.ReportName = "RT2008.PriceMgmt.Reports.PriceHistoryRdl.rdlc";
                }
                else if (this.ReportType.ToString().Substring(0, 1) == "D")
                {
                    view.ReportName = "RT2008.PriceMgmt.Reports.DiscountHistoryRdl.rdlc";
                }

                view.Parameters = param;

                view.Show();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}