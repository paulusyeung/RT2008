namespace RT2008.EmulatedPoS
{
    partial class AnalysisCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Visual WebGui UserControl Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Gizmox.WebGUI.Forms.Panel();
            this.groupBox13 = new Gizmox.WebGUI.Forms.GroupBox();
            this.btnOk = new Gizmox.WebGUI.Forms.Button();
            this.cboAnalysisCode10 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label62 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode09 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label61 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode08 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label60 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode07 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label59 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode06 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label58 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode05 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label57 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode04 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label56 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode03 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label55 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode02 = new Gizmox.WebGUI.Forms.ComboBox();
            this.label54 = new Gizmox.WebGUI.Forms.Label();
            this.label53 = new Gizmox.WebGUI.Forms.Label();
            this.cboAnalysisCode01 = new Gizmox.WebGUI.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = Gizmox.WebGUI.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.groupBox13);
            this.panel1.Dock = Gizmox.WebGUI.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(617, 326);
            this.panel1.TabIndex = 0;
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = Gizmox.WebGUI.Forms.AnchorStyles.None;
            this.groupBox13.Controls.Add(this.btnOk);
            this.groupBox13.Controls.Add(this.cboAnalysisCode10);
            this.groupBox13.Controls.Add(this.label62);
            this.groupBox13.Controls.Add(this.cboAnalysisCode09);
            this.groupBox13.Controls.Add(this.label61);
            this.groupBox13.Controls.Add(this.cboAnalysisCode08);
            this.groupBox13.Controls.Add(this.label60);
            this.groupBox13.Controls.Add(this.cboAnalysisCode07);
            this.groupBox13.Controls.Add(this.label59);
            this.groupBox13.Controls.Add(this.cboAnalysisCode06);
            this.groupBox13.Controls.Add(this.label58);
            this.groupBox13.Controls.Add(this.cboAnalysisCode05);
            this.groupBox13.Controls.Add(this.label57);
            this.groupBox13.Controls.Add(this.cboAnalysisCode04);
            this.groupBox13.Controls.Add(this.label56);
            this.groupBox13.Controls.Add(this.cboAnalysisCode03);
            this.groupBox13.Controls.Add(this.label55);
            this.groupBox13.Controls.Add(this.cboAnalysisCode02);
            this.groupBox13.Controls.Add(this.label54);
            this.groupBox13.Controls.Add(this.label53);
            this.groupBox13.Controls.Add(this.cboAnalysisCode01);
            this.groupBox13.Dock = Gizmox.WebGUI.Forms.DockStyle.Fill;
            this.groupBox13.FlatStyle = Gizmox.WebGUI.Forms.FlatStyle.Flat;
            this.groupBox13.Location = new System.Drawing.Point(0, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(617, 326);
            this.groupBox13.TabIndex = 1;
            this.groupBox13.Text = "Analysis Code";
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(527, 289);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 3;
            this.btnOk.Text = "OK";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // cboAnalysisCode10
            // 
            this.cboAnalysisCode10.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode10.Location = new System.Drawing.Point(150, 262);
            this.cboAnalysisCode10.Name = "cboAnalysisCode10";
            this.cboAnalysisCode10.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode10.TabIndex = 2;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(9, 266);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(97, 13);
            this.label62.TabIndex = 0;
            this.label62.Text = "Analysis Code #10";
            // 
            // cboAnalysisCode09
            // 
            this.cboAnalysisCode09.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode09.Location = new System.Drawing.Point(150, 235);
            this.cboAnalysisCode09.Name = "cboAnalysisCode09";
            this.cboAnalysisCode09.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode09.TabIndex = 2;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(9, 239);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(97, 13);
            this.label61.TabIndex = 0;
            this.label61.Text = "Analysis Code #09";
            // 
            // cboAnalysisCode08
            // 
            this.cboAnalysisCode08.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode08.Location = new System.Drawing.Point(150, 208);
            this.cboAnalysisCode08.Name = "cboAnalysisCode08";
            this.cboAnalysisCode08.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode08.TabIndex = 2;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(9, 212);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(97, 13);
            this.label60.TabIndex = 0;
            this.label60.Text = "Analysis Code #08";
            // 
            // cboAnalysisCode07
            // 
            this.cboAnalysisCode07.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode07.Location = new System.Drawing.Point(150, 181);
            this.cboAnalysisCode07.Name = "cboAnalysisCode07";
            this.cboAnalysisCode07.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode07.TabIndex = 2;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(9, 185);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(97, 13);
            this.label59.TabIndex = 0;
            this.label59.Text = "Analysis Code #07";
            // 
            // cboAnalysisCode06
            // 
            this.cboAnalysisCode06.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode06.Location = new System.Drawing.Point(150, 154);
            this.cboAnalysisCode06.Name = "cboAnalysisCode06";
            this.cboAnalysisCode06.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode06.TabIndex = 2;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(9, 158);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(97, 13);
            this.label58.TabIndex = 0;
            this.label58.Text = "Analysis Code #06";
            // 
            // cboAnalysisCode05
            // 
            this.cboAnalysisCode05.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode05.Location = new System.Drawing.Point(150, 127);
            this.cboAnalysisCode05.Name = "cboAnalysisCode05";
            this.cboAnalysisCode05.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode05.TabIndex = 2;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(9, 131);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(97, 13);
            this.label57.TabIndex = 0;
            this.label57.Text = "Analysis Code #05";
            // 
            // cboAnalysisCode04
            // 
            this.cboAnalysisCode04.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode04.Location = new System.Drawing.Point(150, 100);
            this.cboAnalysisCode04.Name = "cboAnalysisCode04";
            this.cboAnalysisCode04.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode04.TabIndex = 2;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(9, 104);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(97, 13);
            this.label56.TabIndex = 0;
            this.label56.Text = "Analysis Code #04";
            // 
            // cboAnalysisCode03
            // 
            this.cboAnalysisCode03.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode03.Location = new System.Drawing.Point(150, 73);
            this.cboAnalysisCode03.Name = "cboAnalysisCode03";
            this.cboAnalysisCode03.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode03.TabIndex = 2;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(9, 77);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(97, 13);
            this.label55.TabIndex = 0;
            this.label55.Text = "Analysis Code #03";
            // 
            // cboAnalysisCode02
            // 
            this.cboAnalysisCode02.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode02.Location = new System.Drawing.Point(150, 46);
            this.cboAnalysisCode02.Name = "cboAnalysisCode02";
            this.cboAnalysisCode02.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode02.TabIndex = 2;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(9, 50);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(97, 13);
            this.label54.TabIndex = 0;
            this.label54.Text = "Analysis Code #02";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(9, 23);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(19, 13);
            this.label53.TabIndex = 0;
            this.label53.Text = "Bill";
            // 
            // cboAnalysisCode01
            // 
            this.cboAnalysisCode01.BorderStyle = Gizmox.WebGUI.Forms.BorderStyle.Fixed3D;
            this.cboAnalysisCode01.Location = new System.Drawing.Point(150, 19);
            this.cboAnalysisCode01.Name = "cboAnalysisCode01";
            this.cboAnalysisCode01.Size = new System.Drawing.Size(452, 21);
            this.cboAnalysisCode01.TabIndex = 2;
            // 
            // AnalysisCode
            // 
            this.Controls.Add(this.panel1);
            this.Size = new System.Drawing.Size(617, 326);
            this.Text = "FastModeLogin";
            this.ResumeLayout(false);

        }

        #endregion

        private Gizmox.WebGUI.Forms.Panel panel1;
        private Gizmox.WebGUI.Forms.GroupBox groupBox13;
        private Gizmox.WebGUI.Forms.Button btnOk;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode10;
        private Gizmox.WebGUI.Forms.Label label62;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode09;
        private Gizmox.WebGUI.Forms.Label label61;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode08;
        private Gizmox.WebGUI.Forms.Label label60;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode07;
        private Gizmox.WebGUI.Forms.Label label59;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode06;
        private Gizmox.WebGUI.Forms.Label label58;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode05;
        private Gizmox.WebGUI.Forms.Label label57;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode04;
        private Gizmox.WebGUI.Forms.Label label56;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode03;
        private Gizmox.WebGUI.Forms.Label label55;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode02;
        private Gizmox.WebGUI.Forms.Label label54;
        private Gizmox.WebGUI.Forms.Label label53;
        private Gizmox.WebGUI.Forms.ComboBox cboAnalysisCode01;





    }
}