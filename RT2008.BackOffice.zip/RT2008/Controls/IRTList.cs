﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RT2008.Controls
{
    public interface IRTList
    {
        void BindRTList(bool bFind);
    }
}
