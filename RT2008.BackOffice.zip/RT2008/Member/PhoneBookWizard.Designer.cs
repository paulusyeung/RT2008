namespace RT2008.Member
{
    partial class PhoneBookWizard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPhoneTag5 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblPhoneTag5 = new Gizmox.WebGUI.Forms.Label();
            this.txtPhoneTag4 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtPhoneTag3 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtPhoneTag2 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtPhoneTag1 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblPhoneTag4 = new Gizmox.WebGUI.Forms.Label();
            this.lblPhoneTag3 = new Gizmox.WebGUI.Forms.Label();
            this.lblPhoneTag2 = new Gizmox.WebGUI.Forms.Label();
            this.lblPhoneTag1 = new Gizmox.WebGUI.Forms.Label();
            this.tbWizardAction = new Gizmox.WebGUI.Forms.ToolBar();
            this.lblVipNumber = new Gizmox.WebGUI.Forms.Label();
            this.txtVipNumber = new Gizmox.WebGUI.Forms.TextBox();
            this.lblPhoneBook = new Gizmox.WebGUI.Forms.Label();
            this.txtPhoneBook = new Gizmox.WebGUI.Forms.TextBox();
            this.lblType = new Gizmox.WebGUI.Forms.Label();
            this.txtType = new Gizmox.WebGUI.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtPhoneTag5
            // 
            this.txtPhoneTag5.Location = new System.Drawing.Point(98, 211);
            this.txtPhoneTag5.Name = "txtPhoneTag5";
            this.txtPhoneTag5.Size = new System.Drawing.Size(268, 20);
            this.txtPhoneTag5.TabIndex = 30;
            // 
            // lblPhoneTag5
            // 
            this.lblPhoneTag5.Location = new System.Drawing.Point(12, 214);
            this.lblPhoneTag5.Name = "lblPhoneTag5";
            this.lblPhoneTag5.Size = new System.Drawing.Size(80, 23);
            this.lblPhoneTag5.TabIndex = 29;
            this.lblPhoneTag5.Text = "Phone 5:";
            // 
            // txtPhoneTag4
            // 
            this.txtPhoneTag4.Location = new System.Drawing.Point(98, 188);
            this.txtPhoneTag4.Name = "txtPhoneTag4";
            this.txtPhoneTag4.Size = new System.Drawing.Size(268, 20);
            this.txtPhoneTag4.TabIndex = 28;
            // 
            // txtPhoneTag3
            // 
            this.txtPhoneTag3.Location = new System.Drawing.Point(98, 165);
            this.txtPhoneTag3.Name = "txtPhoneTag3";
            this.txtPhoneTag3.Size = new System.Drawing.Size(268, 20);
            this.txtPhoneTag3.TabIndex = 27;
            // 
            // txtPhoneTag2
            // 
            this.txtPhoneTag2.Location = new System.Drawing.Point(98, 142);
            this.txtPhoneTag2.Name = "txtPhoneTag2";
            this.txtPhoneTag2.Size = new System.Drawing.Size(268, 20);
            this.txtPhoneTag2.TabIndex = 26;
            // 
            // txtPhoneTag1
            // 
            this.txtPhoneTag1.Location = new System.Drawing.Point(98, 119);
            this.txtPhoneTag1.Name = "txtPhoneTag1";
            this.txtPhoneTag1.Size = new System.Drawing.Size(268, 20);
            this.txtPhoneTag1.TabIndex = 25;
            // 
            // lblPhoneTag4
            // 
            this.lblPhoneTag4.Location = new System.Drawing.Point(12, 191);
            this.lblPhoneTag4.Name = "lblPhoneTag4";
            this.lblPhoneTag4.Size = new System.Drawing.Size(80, 23);
            this.lblPhoneTag4.TabIndex = 24;
            this.lblPhoneTag4.Text = "Phone 4:";
            // 
            // lblPhoneTag3
            // 
            this.lblPhoneTag3.Location = new System.Drawing.Point(12, 168);
            this.lblPhoneTag3.Name = "lblPhoneTag3";
            this.lblPhoneTag3.Size = new System.Drawing.Size(80, 23);
            this.lblPhoneTag3.TabIndex = 23;
            this.lblPhoneTag3.Text = "Phone 3:";
            // 
            // lblPhoneTag2
            // 
            this.lblPhoneTag2.Location = new System.Drawing.Point(12, 145);
            this.lblPhoneTag2.Name = "lblPhoneTag2";
            this.lblPhoneTag2.Size = new System.Drawing.Size(80, 23);
            this.lblPhoneTag2.TabIndex = 22;
            this.lblPhoneTag2.Text = "Phone 2:";
            // 
            // lblPhoneTag1
            // 
            this.lblPhoneTag1.Location = new System.Drawing.Point(12, 122);
            this.lblPhoneTag1.Name = "lblPhoneTag1";
            this.lblPhoneTag1.Size = new System.Drawing.Size(80, 23);
            this.lblPhoneTag1.TabIndex = 21;
            this.lblPhoneTag1.Text = "Phone 1:";
            // 
            // tbWizardAction
            // 
            this.tbWizardAction.Anchor = Gizmox.WebGUI.Forms.AnchorStyles.None;
            this.tbWizardAction.Appearance = Gizmox.WebGUI.Forms.ToolBarAppearance.Normal;
            this.tbWizardAction.Dock = Gizmox.WebGUI.Forms.DockStyle.Top;
            this.tbWizardAction.DragHandle = true;
            this.tbWizardAction.DropDownArrows = false;
            this.tbWizardAction.ImageList = null;
            this.tbWizardAction.Location = new System.Drawing.Point(0, 0);
            this.tbWizardAction.MenuHandle = true;
            this.tbWizardAction.Name = "tbWizardAction";
            //this.tbWizardAction.RightToLeft = false;
            this.tbWizardAction.ShowToolTips = true;
            this.tbWizardAction.TabIndex = 31;
            // 
            // lblVipNumber
            // 
            this.lblVipNumber.Location = new System.Drawing.Point(12, 41);
            this.lblVipNumber.Name = "lblVipNumber";
            this.lblVipNumber.Size = new System.Drawing.Size(80, 23);
            this.lblVipNumber.TabIndex = 32;
            this.lblVipNumber.Text = "VIP Number:";
            // 
            // txtVipNumber
            // 
            this.txtVipNumber.BackColor = System.Drawing.Color.LightYellow;
            this.txtVipNumber.Location = new System.Drawing.Point(98, 38);
            this.txtVipNumber.Name = "txtVipNumber";
            this.txtVipNumber.ReadOnly = true;
            this.txtVipNumber.Size = new System.Drawing.Size(100, 20);
            this.txtVipNumber.TabIndex = 33;
            // 
            // lblPhoneBook
            // 
            this.lblPhoneBook.Location = new System.Drawing.Point(12, 64);
            this.lblPhoneBook.Name = "lblPhoneBook";
            this.lblPhoneBook.Size = new System.Drawing.Size(80, 23);
            this.lblPhoneBook.TabIndex = 34;
            this.lblPhoneBook.Text = "Phone Book:";
            // 
            // txtPhoneBook
            // 
            this.txtPhoneBook.BackColor = System.Drawing.Color.LightYellow;
            this.txtPhoneBook.Location = new System.Drawing.Point(98, 61);
            this.txtPhoneBook.Name = "txtPhoneBook";
            this.txtPhoneBook.ReadOnly = true;
            this.txtPhoneBook.Size = new System.Drawing.Size(100, 20);
            this.txtPhoneBook.TabIndex = 35;
            // 
            // lblType
            // 
            this.lblType.Location = new System.Drawing.Point(12, 87);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(80, 23);
            this.lblType.TabIndex = 36;
            this.lblType.Text = "Type:";
            // 
            // txtType
            // 
            this.txtType.BackColor = System.Drawing.Color.LightYellow;
            this.txtType.Location = new System.Drawing.Point(98, 84);
            this.txtType.Name = "txtType";
            this.txtType.ReadOnly = true;
            this.txtType.Size = new System.Drawing.Size(100, 20);
            this.txtType.TabIndex = 37;
            // 
            // PhoneBookWizard
            // 
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.txtPhoneBook);
            this.Controls.Add(this.lblPhoneBook);
            this.Controls.Add(this.txtVipNumber);
            this.Controls.Add(this.lblVipNumber);
            this.Controls.Add(this.tbWizardAction);
            this.Controls.Add(this.lblPhoneTag1);
            this.Controls.Add(this.lblPhoneTag2);
            this.Controls.Add(this.lblPhoneTag3);
            this.Controls.Add(this.lblPhoneTag4);
            this.Controls.Add(this.txtPhoneTag1);
            this.Controls.Add(this.txtPhoneTag2);
            this.Controls.Add(this.txtPhoneTag3);
            this.Controls.Add(this.txtPhoneTag4);
            this.Controls.Add(this.lblPhoneTag5);
            this.Controls.Add(this.txtPhoneTag5);
            this.Size = new System.Drawing.Size(419, 466);
            this.Text = "PhoneBookWizard";
            this.ResumeLayout(false);

        }

        #endregion

        public Gizmox.WebGUI.Forms.TextBox txtPhoneTag5;
        private Gizmox.WebGUI.Forms.Label lblPhoneTag5;
        public Gizmox.WebGUI.Forms.TextBox txtPhoneTag4;
        public Gizmox.WebGUI.Forms.TextBox txtPhoneTag3;
        public Gizmox.WebGUI.Forms.TextBox txtPhoneTag2;
        public Gizmox.WebGUI.Forms.TextBox txtPhoneTag1;
        private Gizmox.WebGUI.Forms.Label lblPhoneTag4;
        private Gizmox.WebGUI.Forms.Label lblPhoneTag3;
        private Gizmox.WebGUI.Forms.Label lblPhoneTag2;
        private Gizmox.WebGUI.Forms.Label lblPhoneTag1;
        private Gizmox.WebGUI.Forms.ToolBar tbWizardAction;
        private Gizmox.WebGUI.Forms.Label lblVipNumber;
        private Gizmox.WebGUI.Forms.TextBox txtVipNumber;
        private Gizmox.WebGUI.Forms.Label lblPhoneBook;
        private Gizmox.WebGUI.Forms.TextBox txtPhoneBook;
        private Gizmox.WebGUI.Forms.Label lblType;
        private Gizmox.WebGUI.Forms.TextBox txtType;


    }
}