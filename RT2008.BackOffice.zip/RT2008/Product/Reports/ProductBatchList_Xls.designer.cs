namespace RT2008.Product.Reports
{
    partial class ProductBatchList_Xls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
            this.oleDbCommand1 = new System.Data.OleDb.OleDbCommand();
            this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.GroupFooter1 = new DevExpress.XtraReports.UI.GroupFooterBand();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.Text12 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text2 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text3 = new DevExpress.XtraReports.UI.XRLabel();
            this.PrintDate1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text4 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text5 = new DevExpress.XtraReports.UI.XRLabel();
            this.PageNumber1 = new DevExpress.XtraReports.UI.XRPageInfo();
            this.TotalPageCount1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text6 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text7 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text8 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text9 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text10 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text13 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text14 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text15 = new DevExpress.XtraReports.UI.XRLabel();
            this.App1C1 = new DevExpress.XtraReports.UI.XRLabel();
            this.App2C1 = new DevExpress.XtraReports.UI.XRLabel();
            this.App3c1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Line1 = new DevExpress.XtraReports.UI.XRLine();
            this.hdrStkCode1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PrintTime1 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrCompName1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.STKCODE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.APP2COMBIN1 = new DevExpress.XtraReports.UI.XRLabel();
            this.APP3COMBIN1 = new DevExpress.XtraReports.UI.XRLabel();
            this.CLASS11 = new DevExpress.XtraReports.UI.XRLabel();
            this.CLASS21 = new DevExpress.XtraReports.UI.XRLabel();
            this.CLASS31 = new DevExpress.XtraReports.UI.XRLabel();
            this.CLASS51 = new DevExpress.XtraReports.UI.XRLabel();
            this.DESC1 = new DevExpress.XtraReports.UI.XRLabel();
            this.MAINUNIT1 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATECREATE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.CLASS41 = new DevExpress.XtraReports.UI.XRLabel();
            this.CLASS61 = new DevExpress.XtraReports.UI.XRLabel();
            this.BASPRC1 = new DevExpress.XtraReports.UI.XRLabel();
            this.WHLPRC1 = new DevExpress.XtraReports.UI.XRLabel();
            this.VCURR1 = new DevExpress.XtraReports.UI.XRLabel();
            this.VPRC1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text38 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text39 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text40 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text41 = new DevExpress.XtraReports.UI.XRLabel();
            this.StatusP1 = new DevExpress.XtraReports.UI.XRLabel();
            this.APP1COMBIN1 = new DevExpress.XtraReports.UI.XRLabel();
            this.ReportFooter = new DevExpress.XtraReports.UI.ReportFooterBand();
            this.endofreport1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Line2 = new DevExpress.XtraReports.UI.XRLine();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            this.Text52 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text53 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text54 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text55 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text56 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text57 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class12 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class22 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class32 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class42 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class52 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class62 = new DevExpress.XtraReports.UI.XRLabel();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.APP1COMBIN1,
            this.StatusP1,
            this.Text41,
            this.Text40,
            this.Text39,
            this.Text38,
            this.VPRC1,
            this.VCURR1,
            this.WHLPRC1,
            this.BASPRC1,
            this.CLASS61,
            this.CLASS41,
            this.DATECREATE1,
            this.MAINUNIT1,
            this.DESC1,
            this.CLASS51,
            this.CLASS31,
            this.CLASS21,
            this.CLASS11,
            this.APP3COMBIN1,
            this.APP2COMBIN1,
            this.STKCODE1});
            this.Detail.Height = 25;
            this.Detail.Name = "Detail";
            // 
            // oleDbDataAdapter1
            // 
            this.oleDbDataAdapter1.SelectCommand = this.oleDbCommand1;
            this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblStockBatch", new System.Data.Common.DataColumnMapping[0])});
            // 
            // oleDbCommand1
            // 
            this.oleDbCommand1.CommandText = "SELECT * FROM tblStockBatch";
            this.oleDbCommand1.Connection = this.oleDbConnection1;
            // 
            // oleDbConnection1
            // 
            this.oleDbConnection1.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=.\\rptCM1520.mdb";
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.GroupFields.AddRange(new DevExpress.XtraReports.UI.GroupField[] {
            new DevExpress.XtraReports.UI.GroupField("STKCODE", DevExpress.XtraReports.UI.XRColumnSortOrder.Ascending)});
            this.GroupHeader1.Height = 2;
            this.GroupHeader1.Name = "GroupHeader1";
            // 
            // GroupFooter1
            // 
            this.GroupFooter1.Height = 2;
            this.GroupFooter1.Name = "GroupFooter1";
            // 
            // ReportHeader
            // 
            this.ReportHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.hdrCompName1,
            this.PrintTime1,
            this.hdrStkCode1,
            this.Line1,
            this.App3c1,
            this.App2C1,
            this.App1C1,
            this.Text15,
            this.Text14,
            this.Text13,
            this.Text11,
            this.Text10,
            this.Text9,
            this.Text8,
            this.Text7,
            this.Text6,
            this.TotalPageCount1,
            this.PageNumber1,
            this.Text5,
            this.Text4,
            this.PrintDate1,
            this.Text3,
            this.Text2,
            this.Text1,
            this.Text12});
            this.ReportHeader.Height = 115;
            this.ReportHeader.Name = "ReportHeader";
            // 
            // Text12
            // 
            this.Text12.BackColor = System.Drawing.Color.White;
            this.Text12.BorderColor = System.Drawing.Color.Black;
            this.Text12.CanGrow = false;
            this.Text12.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text12.ForeColor = System.Drawing.Color.Black;
            this.Text12.Location = new System.Drawing.Point(476, 99);
            this.Text12.Name = "Text12";
            this.Text12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text12.ParentStyleUsing.UseBackColor = false;
            this.Text12.ParentStyleUsing.UseBorderColor = false;
            this.Text12.ParentStyleUsing.UseBorders = false;
            this.Text12.ParentStyleUsing.UseBorderWidth = false;
            this.Text12.ParentStyleUsing.UseFont = false;
            this.Text12.ParentStyleUsing.UseForeColor = false;
            this.Text12.Size = new System.Drawing.Size(31, 15);
            this.Text12.Text = "C6";
            this.Text12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text1
            // 
            this.Text1.BackColor = System.Drawing.Color.White;
            this.Text1.BorderColor = System.Drawing.Color.Black;
            this.Text1.CanGrow = false;
            this.Text1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text1.ForeColor = System.Drawing.Color.Black;
            this.Text1.Location = new System.Drawing.Point(508, 99);
            this.Text1.Name = "Text1";
            this.Text1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text1.ParentStyleUsing.UseBackColor = false;
            this.Text1.ParentStyleUsing.UseBorderColor = false;
            this.Text1.ParentStyleUsing.UseBorders = false;
            this.Text1.ParentStyleUsing.UseBorderWidth = false;
            this.Text1.ParentStyleUsing.UseFont = false;
            this.Text1.ParentStyleUsing.UseForeColor = false;
            this.Text1.Size = new System.Drawing.Size(181, 15);
            this.Text1.Text = "DESCRIPTION";
            // 
            // Text2
            // 
            this.Text2.BackColor = System.Drawing.Color.White;
            this.Text2.BorderColor = System.Drawing.Color.Black;
            this.Text2.CanGrow = false;
            this.Text2.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text2.ForeColor = System.Drawing.Color.Black;
            this.Text2.Location = new System.Drawing.Point(658, 99);
            this.Text2.Name = "Text2";
            this.Text2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text2.ParentStyleUsing.UseBackColor = false;
            this.Text2.ParentStyleUsing.UseBorderColor = false;
            this.Text2.ParentStyleUsing.UseBorders = false;
            this.Text2.ParentStyleUsing.UseBorderWidth = false;
            this.Text2.ParentStyleUsing.UseFont = false;
            this.Text2.ParentStyleUsing.UseForeColor = false;
            this.Text2.Size = new System.Drawing.Size(34, 15);
            this.Text2.Text = "UNIT";
            this.Text2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text3
            // 
            this.Text3.BackColor = System.Drawing.Color.White;
            this.Text3.BorderColor = System.Drawing.Color.Black;
            this.Text3.CanGrow = false;
            this.Text3.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text3.ForeColor = System.Drawing.Color.Black;
            this.Text3.Location = new System.Drawing.Point(692, 99);
            this.Text3.Name = "Text3";
            this.Text3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text3.ParentStyleUsing.UseBackColor = false;
            this.Text3.ParentStyleUsing.UseBorderColor = false;
            this.Text3.ParentStyleUsing.UseBorders = false;
            this.Text3.ParentStyleUsing.UseBorderWidth = false;
            this.Text3.ParentStyleUsing.UseFont = false;
            this.Text3.ParentStyleUsing.UseForeColor = false;
            this.Text3.Size = new System.Drawing.Size(54, 15);
            this.Text3.Text = "CREATE";
            this.Text3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // PrintDate1
            // 
            this.PrintDate1.BackColor = System.Drawing.Color.White;
            this.PrintDate1.BorderColor = System.Drawing.Color.Black;
            this.PrintDate1.CanGrow = false;
            this.PrintDate1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PrintDate1.ForeColor = System.Drawing.Color.Black;
            this.PrintDate1.Location = new System.Drawing.Point(605, 38);
            this.PrintDate1.Name = "PrintDate1";
            this.PrintDate1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PrintDate1.ParentStyleUsing.UseBackColor = false;
            this.PrintDate1.ParentStyleUsing.UseBorderColor = false;
            this.PrintDate1.ParentStyleUsing.UseBorders = false;
            this.PrintDate1.ParentStyleUsing.UseBorderWidth = false;
            this.PrintDate1.ParentStyleUsing.UseFont = false;
            this.PrintDate1.ParentStyleUsing.UseForeColor = false;
            this.PrintDate1.Size = new System.Drawing.Size(51, 12);
            this.PrintDate1.Text = "Untranslated";
            // 
            // Text4
            // 
            this.Text4.BackColor = System.Drawing.Color.White;
            this.Text4.BorderColor = System.Drawing.Color.Black;
            this.Text4.CanGrow = false;
            this.Text4.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold);
            this.Text4.ForeColor = System.Drawing.Color.Black;
            this.Text4.Location = new System.Drawing.Point(0, 20);
            this.Text4.Name = "Text4";
            this.Text4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text4.ParentStyleUsing.UseBackColor = false;
            this.Text4.ParentStyleUsing.UseBorderColor = false;
            this.Text4.ParentStyleUsing.UseBorders = false;
            this.Text4.ParentStyleUsing.UseBorderWidth = false;
            this.Text4.ParentStyleUsing.UseFont = false;
            this.Text4.ParentStyleUsing.UseForeColor = false;
            this.Text4.Size = new System.Drawing.Size(520, 17);
            this.Text4.Text = "CM1520 - Stock Status in Batch Mode (Ready for Post)";
            // 
            // Text5
            // 
            this.Text5.BackColor = System.Drawing.Color.White;
            this.Text5.BorderColor = System.Drawing.Color.Black;
            this.Text5.CanGrow = false;
            this.Text5.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text5.ForeColor = System.Drawing.Color.Black;
            this.Text5.Location = new System.Drawing.Point(528, 38);
            this.Text5.Name = "Text5";
            this.Text5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text5.ParentStyleUsing.UseBackColor = false;
            this.Text5.ParentStyleUsing.UseBorderColor = false;
            this.Text5.ParentStyleUsing.UseBorders = false;
            this.Text5.ParentStyleUsing.UseBorderWidth = false;
            this.Text5.ParentStyleUsing.UseFont = false;
            this.Text5.ParentStyleUsing.UseForeColor = false;
            this.Text5.Size = new System.Drawing.Size(71, 16);
            this.Text5.Text = "Print At :";
            this.Text5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // PageNumber1
            // 
            this.PageNumber1.BackColor = System.Drawing.Color.White;
            this.PageNumber1.BorderColor = System.Drawing.Color.Black;
            this.PageNumber1.CanGrow = false;
            this.PageNumber1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PageNumber1.ForeColor = System.Drawing.Color.Black;
            this.PageNumber1.Location = new System.Drawing.Point(605, 54);
            this.PageNumber1.Name = "PageNumber1";
            this.PageNumber1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PageNumber1.PageInfo = DevExpress.XtraPrinting.PageInfo.Number;
            this.PageNumber1.ParentStyleUsing.UseBackColor = false;
            this.PageNumber1.ParentStyleUsing.UseBorderColor = false;
            this.PageNumber1.ParentStyleUsing.UseBorders = false;
            this.PageNumber1.ParentStyleUsing.UseBorderWidth = false;
            this.PageNumber1.ParentStyleUsing.UseFont = false;
            this.PageNumber1.ParentStyleUsing.UseForeColor = false;
            this.PageNumber1.Size = new System.Drawing.Size(22, 12);
            // 
            // TotalPageCount1
            // 
            this.TotalPageCount1.BackColor = System.Drawing.Color.White;
            this.TotalPageCount1.BorderColor = System.Drawing.Color.Black;
            this.TotalPageCount1.CanGrow = false;
            this.TotalPageCount1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.TotalPageCount1.ForeColor = System.Drawing.Color.Black;
            this.TotalPageCount1.Location = new System.Drawing.Point(658, 54);
            this.TotalPageCount1.Name = "TotalPageCount1";
            this.TotalPageCount1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TotalPageCount1.ParentStyleUsing.UseBackColor = false;
            this.TotalPageCount1.ParentStyleUsing.UseBorderColor = false;
            this.TotalPageCount1.ParentStyleUsing.UseBorders = false;
            this.TotalPageCount1.ParentStyleUsing.UseBorderWidth = false;
            this.TotalPageCount1.ParentStyleUsing.UseFont = false;
            this.TotalPageCount1.ParentStyleUsing.UseForeColor = false;
            this.TotalPageCount1.Size = new System.Drawing.Size(34, 12);
            this.TotalPageCount1.Text = "Untranslated";
            // 
            // Text6
            // 
            this.Text6.BackColor = System.Drawing.Color.White;
            this.Text6.BorderColor = System.Drawing.Color.Black;
            this.Text6.CanGrow = false;
            this.Text6.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text6.ForeColor = System.Drawing.Color.Black;
            this.Text6.Location = new System.Drawing.Point(528, 54);
            this.Text6.Name = "Text6";
            this.Text6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text6.ParentStyleUsing.UseBackColor = false;
            this.Text6.ParentStyleUsing.UseBorderColor = false;
            this.Text6.ParentStyleUsing.UseBorders = false;
            this.Text6.ParentStyleUsing.UseBorderWidth = false;
            this.Text6.ParentStyleUsing.UseFont = false;
            this.Text6.ParentStyleUsing.UseForeColor = false;
            this.Text6.Size = new System.Drawing.Size(71, 15);
            this.Text6.Text = "Page :";
            this.Text6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text7
            // 
            this.Text7.BackColor = System.Drawing.Color.White;
            this.Text7.BorderColor = System.Drawing.Color.Black;
            this.Text7.CanGrow = false;
            this.Text7.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text7.ForeColor = System.Drawing.Color.Black;
            this.Text7.Location = new System.Drawing.Point(626, 54);
            this.Text7.Name = "Text7";
            this.Text7.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text7.ParentStyleUsing.UseBackColor = false;
            this.Text7.ParentStyleUsing.UseBorderColor = false;
            this.Text7.ParentStyleUsing.UseBorders = false;
            this.Text7.ParentStyleUsing.UseBorderWidth = false;
            this.Text7.ParentStyleUsing.UseFont = false;
            this.Text7.ParentStyleUsing.UseForeColor = false;
            this.Text7.Size = new System.Drawing.Size(32, 15);
            this.Text7.Text = "of";
            this.Text7.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text8
            // 
            this.Text8.BackColor = System.Drawing.Color.White;
            this.Text8.BorderColor = System.Drawing.Color.Black;
            this.Text8.CanGrow = false;
            this.Text8.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text8.ForeColor = System.Drawing.Color.Black;
            this.Text8.Location = new System.Drawing.Point(310, 99);
            this.Text8.Name = "Text8";
            this.Text8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text8.ParentStyleUsing.UseBackColor = false;
            this.Text8.ParentStyleUsing.UseBorderColor = false;
            this.Text8.ParentStyleUsing.UseBorders = false;
            this.Text8.ParentStyleUsing.UseBorderWidth = false;
            this.Text8.ParentStyleUsing.UseFont = false;
            this.Text8.ParentStyleUsing.UseForeColor = false;
            this.Text8.Size = new System.Drawing.Size(33, 15);
            this.Text8.Text = "C1";
            this.Text8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text9
            // 
            this.Text9.BackColor = System.Drawing.Color.White;
            this.Text9.BorderColor = System.Drawing.Color.Black;
            this.Text9.CanGrow = false;
            this.Text9.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text9.ForeColor = System.Drawing.Color.Black;
            this.Text9.Location = new System.Drawing.Point(344, 99);
            this.Text9.Name = "Text9";
            this.Text9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text9.ParentStyleUsing.UseBackColor = false;
            this.Text9.ParentStyleUsing.UseBorderColor = false;
            this.Text9.ParentStyleUsing.UseBorders = false;
            this.Text9.ParentStyleUsing.UseBorderWidth = false;
            this.Text9.ParentStyleUsing.UseFont = false;
            this.Text9.ParentStyleUsing.UseForeColor = false;
            this.Text9.Size = new System.Drawing.Size(33, 15);
            this.Text9.Text = "C2";
            this.Text9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text10
            // 
            this.Text10.BackColor = System.Drawing.Color.White;
            this.Text10.BorderColor = System.Drawing.Color.Black;
            this.Text10.CanGrow = false;
            this.Text10.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text10.ForeColor = System.Drawing.Color.Black;
            this.Text10.Location = new System.Drawing.Point(378, 99);
            this.Text10.Name = "Text10";
            this.Text10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text10.ParentStyleUsing.UseBackColor = false;
            this.Text10.ParentStyleUsing.UseBorderColor = false;
            this.Text10.ParentStyleUsing.UseBorders = false;
            this.Text10.ParentStyleUsing.UseBorderWidth = false;
            this.Text10.ParentStyleUsing.UseFont = false;
            this.Text10.ParentStyleUsing.UseForeColor = false;
            this.Text10.Size = new System.Drawing.Size(33, 15);
            this.Text10.Text = "C3";
            this.Text10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text11
            // 
            this.Text11.BackColor = System.Drawing.Color.White;
            this.Text11.BorderColor = System.Drawing.Color.Black;
            this.Text11.CanGrow = false;
            this.Text11.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text11.ForeColor = System.Drawing.Color.Black;
            this.Text11.Location = new System.Drawing.Point(443, 99);
            this.Text11.Name = "Text11";
            this.Text11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text11.ParentStyleUsing.UseBackColor = false;
            this.Text11.ParentStyleUsing.UseBorderColor = false;
            this.Text11.ParentStyleUsing.UseBorders = false;
            this.Text11.ParentStyleUsing.UseBorderWidth = false;
            this.Text11.ParentStyleUsing.UseFont = false;
            this.Text11.ParentStyleUsing.UseForeColor = false;
            this.Text11.Size = new System.Drawing.Size(32, 15);
            this.Text11.Text = "C5";
            this.Text11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text13
            // 
            this.Text13.BackColor = System.Drawing.Color.White;
            this.Text13.BorderColor = System.Drawing.Color.Black;
            this.Text13.CanGrow = false;
            this.Text13.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text13.ForeColor = System.Drawing.Color.Black;
            this.Text13.Location = new System.Drawing.Point(411, 99);
            this.Text13.Name = "Text13";
            this.Text13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text13.ParentStyleUsing.UseBackColor = false;
            this.Text13.ParentStyleUsing.UseBorderColor = false;
            this.Text13.ParentStyleUsing.UseBorders = false;
            this.Text13.ParentStyleUsing.UseBorderWidth = false;
            this.Text13.ParentStyleUsing.UseFont = false;
            this.Text13.ParentStyleUsing.UseForeColor = false;
            this.Text13.Size = new System.Drawing.Size(32, 15);
            this.Text13.Text = "C4";
            this.Text13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text14
            // 
            this.Text14.BackColor = System.Drawing.Color.White;
            this.Text14.BorderColor = System.Drawing.Color.Black;
            this.Text14.CanGrow = false;
            this.Text14.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text14.ForeColor = System.Drawing.Color.Black;
            this.Text14.Location = new System.Drawing.Point(658, 85);
            this.Text14.Name = "Text14";
            this.Text14.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text14.ParentStyleUsing.UseBackColor = false;
            this.Text14.ParentStyleUsing.UseBorderColor = false;
            this.Text14.ParentStyleUsing.UseBorders = false;
            this.Text14.ParentStyleUsing.UseBorderWidth = false;
            this.Text14.ParentStyleUsing.UseFont = false;
            this.Text14.ParentStyleUsing.UseForeColor = false;
            this.Text14.Size = new System.Drawing.Size(34, 14);
            this.Text14.Text = "MAIN";
            this.Text14.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // Text15
            // 
            this.Text15.BackColor = System.Drawing.Color.White;
            this.Text15.BorderColor = System.Drawing.Color.Black;
            this.Text15.CanGrow = false;
            this.Text15.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text15.ForeColor = System.Drawing.Color.Black;
            this.Text15.Location = new System.Drawing.Point(692, 85);
            this.Text15.Name = "Text15";
            this.Text15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text15.ParentStyleUsing.UseBackColor = false;
            this.Text15.ParentStyleUsing.UseBorderColor = false;
            this.Text15.ParentStyleUsing.UseBorders = false;
            this.Text15.ParentStyleUsing.UseBorderWidth = false;
            this.Text15.ParentStyleUsing.UseFont = false;
            this.Text15.ParentStyleUsing.UseForeColor = false;
            this.Text15.Size = new System.Drawing.Size(54, 14);
            this.Text15.Text = "DATE";
            this.Text15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // App1C1
            // 
            this.App1C1.BackColor = System.Drawing.Color.White;
            this.App1C1.BorderColor = System.Drawing.Color.Black;
            this.App1C1.CanGrow = false;
            this.App1C1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.App1C1.ForeColor = System.Drawing.Color.Black;
            this.App1C1.Location = new System.Drawing.Point(73, 99);
            this.App1C1.Name = "App1C1";
            this.App1C1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.App1C1.ParentStyleUsing.UseBackColor = false;
            this.App1C1.ParentStyleUsing.UseBorderColor = false;
            this.App1C1.ParentStyleUsing.UseBorders = false;
            this.App1C1.ParentStyleUsing.UseBorderWidth = false;
            this.App1C1.ParentStyleUsing.UseFont = false;
            this.App1C1.ParentStyleUsing.UseForeColor = false;
            this.App1C1.Size = new System.Drawing.Size(79, 15);
            this.App1C1.Text = "Untranslated";
            // 
            // App2C1
            // 
            this.App2C1.BackColor = System.Drawing.Color.White;
            this.App2C1.BorderColor = System.Drawing.Color.Black;
            this.App2C1.CanGrow = false;
            this.App2C1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.App2C1.ForeColor = System.Drawing.Color.Black;
            this.App2C1.Location = new System.Drawing.Point(153, 99);
            this.App2C1.Name = "App2C1";
            this.App2C1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.App2C1.ParentStyleUsing.UseBackColor = false;
            this.App2C1.ParentStyleUsing.UseBorderColor = false;
            this.App2C1.ParentStyleUsing.UseBorders = false;
            this.App2C1.ParentStyleUsing.UseBorderWidth = false;
            this.App2C1.ParentStyleUsing.UseFont = false;
            this.App2C1.ParentStyleUsing.UseForeColor = false;
            this.App2C1.Size = new System.Drawing.Size(79, 15);
            this.App2C1.Text = "Untranslated";
            // 
            // App3c1
            // 
            this.App3c1.BackColor = System.Drawing.Color.White;
            this.App3c1.BorderColor = System.Drawing.Color.Black;
            this.App3c1.CanGrow = false;
            this.App3c1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.App3c1.ForeColor = System.Drawing.Color.Black;
            this.App3c1.Location = new System.Drawing.Point(232, 99);
            this.App3c1.Name = "App3c1";
            this.App3c1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.App3c1.ParentStyleUsing.UseBackColor = false;
            this.App3c1.ParentStyleUsing.UseBorderColor = false;
            this.App3c1.ParentStyleUsing.UseBorders = false;
            this.App3c1.ParentStyleUsing.UseBorderWidth = false;
            this.App3c1.ParentStyleUsing.UseFont = false;
            this.App3c1.ParentStyleUsing.UseForeColor = false;
            this.App3c1.Size = new System.Drawing.Size(78, 15);
            this.App3c1.Text = "Untranslated";
            // 
            // Line1
            // 
            this.Line1.BackColor = System.Drawing.Color.White;
            this.Line1.BorderColor = System.Drawing.Color.Black;
            this.Line1.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.Line1.CanGrow = false;
            this.Line1.ForeColor = System.Drawing.Color.Black;
            this.Line1.Location = new System.Drawing.Point(0, 113);
            this.Line1.Name = "Line1";
            this.Line1.ParentStyleUsing.UseBackColor = false;
            this.Line1.ParentStyleUsing.UseBorderColor = false;
            this.Line1.ParentStyleUsing.UseBorders = false;
            this.Line1.ParentStyleUsing.UseBorderWidth = false;
            this.Line1.ParentStyleUsing.UseFont = false;
            this.Line1.ParentStyleUsing.UseForeColor = false;
            this.Line1.Size = new System.Drawing.Size(747, 2);
            // 
            // hdrStkCode1
            // 
            this.hdrStkCode1.BackColor = System.Drawing.Color.White;
            this.hdrStkCode1.BorderColor = System.Drawing.Color.Black;
            this.hdrStkCode1.CanGrow = false;
            this.hdrStkCode1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.hdrStkCode1.ForeColor = System.Drawing.Color.Black;
            this.hdrStkCode1.Location = new System.Drawing.Point(0, 99);
            this.hdrStkCode1.Name = "hdrStkCode1";
            this.hdrStkCode1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrStkCode1.ParentStyleUsing.UseBackColor = false;
            this.hdrStkCode1.ParentStyleUsing.UseBorderColor = false;
            this.hdrStkCode1.ParentStyleUsing.UseBorders = false;
            this.hdrStkCode1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrStkCode1.ParentStyleUsing.UseFont = false;
            this.hdrStkCode1.ParentStyleUsing.UseForeColor = false;
            this.hdrStkCode1.Size = new System.Drawing.Size(73, 15);
            this.hdrStkCode1.Text = "Untranslated";
            // 
            // PrintTime1
            // 
            this.PrintTime1.BackColor = System.Drawing.Color.White;
            this.PrintTime1.BorderColor = System.Drawing.Color.Black;
            this.PrintTime1.CanGrow = false;
            this.PrintTime1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PrintTime1.ForeColor = System.Drawing.Color.Black;
            this.PrintTime1.Location = new System.Drawing.Point(658, 38);
            this.PrintTime1.Name = "PrintTime1";
            this.PrintTime1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PrintTime1.ParentStyleUsing.UseBackColor = false;
            this.PrintTime1.ParentStyleUsing.UseBorderColor = false;
            this.PrintTime1.ParentStyleUsing.UseBorders = false;
            this.PrintTime1.ParentStyleUsing.UseBorderWidth = false;
            this.PrintTime1.ParentStyleUsing.UseFont = false;
            this.PrintTime1.ParentStyleUsing.UseForeColor = false;
            this.PrintTime1.Size = new System.Drawing.Size(88, 12);
            this.PrintTime1.Text = "Untranslated";
            // 
            // hdrCompName1
            // 
            this.hdrCompName1.BackColor = System.Drawing.Color.White;
            this.hdrCompName1.BorderColor = System.Drawing.Color.Black;
            this.hdrCompName1.CanGrow = false;
            this.hdrCompName1.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold);
            this.hdrCompName1.ForeColor = System.Drawing.Color.Black;
            this.hdrCompName1.Location = new System.Drawing.Point(2, 0);
            this.hdrCompName1.Name = "hdrCompName1";
            this.hdrCompName1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrCompName1.ParentStyleUsing.UseBackColor = false;
            this.hdrCompName1.ParentStyleUsing.UseBorderColor = false;
            this.hdrCompName1.ParentStyleUsing.UseBorders = false;
            this.hdrCompName1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrCompName1.ParentStyleUsing.UseFont = false;
            this.hdrCompName1.ParentStyleUsing.UseForeColor = false;
            this.hdrCompName1.Size = new System.Drawing.Size(744, 21);
            this.hdrCompName1.Text = "Untranslated";
            // 
            // PageHeader
            // 
            this.PageHeader.Height = 3;
            this.PageHeader.Name = "PageHeader";
            this.PageHeader.Visible = false;
            // 
            // STKCODE1
            // 
            this.STKCODE1.BackColor = System.Drawing.Color.White;
            this.STKCODE1.BorderColor = System.Drawing.Color.Black;
            this.STKCODE1.CanGrow = false;
            this.STKCODE1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.STKCODE", "")});
            this.STKCODE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.STKCODE1.ForeColor = System.Drawing.Color.Black;
            this.STKCODE1.Location = new System.Drawing.Point(0, 0);
            this.STKCODE1.Name = "STKCODE1";
            this.STKCODE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.STKCODE1.ParentStyleUsing.UseBackColor = false;
            this.STKCODE1.ParentStyleUsing.UseBorderColor = false;
            this.STKCODE1.ParentStyleUsing.UseBorders = false;
            this.STKCODE1.ParentStyleUsing.UseBorderWidth = false;
            this.STKCODE1.ParentStyleUsing.UseFont = false;
            this.STKCODE1.ParentStyleUsing.UseForeColor = false;
            this.STKCODE1.Size = new System.Drawing.Size(73, 12);
            // 
            // APP2COMBIN1
            // 
            this.APP2COMBIN1.BackColor = System.Drawing.Color.White;
            this.APP2COMBIN1.BorderColor = System.Drawing.Color.Black;
            this.APP2COMBIN1.CanGrow = false;
            this.APP2COMBIN1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.APP2_COMBIN", "")});
            this.APP2COMBIN1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.APP2COMBIN1.ForeColor = System.Drawing.Color.Black;
            this.APP2COMBIN1.Location = new System.Drawing.Point(153, 0);
            this.APP2COMBIN1.Name = "APP2COMBIN1";
            this.APP2COMBIN1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.APP2COMBIN1.ParentStyleUsing.UseBackColor = false;
            this.APP2COMBIN1.ParentStyleUsing.UseBorderColor = false;
            this.APP2COMBIN1.ParentStyleUsing.UseBorders = false;
            this.APP2COMBIN1.ParentStyleUsing.UseBorderWidth = false;
            this.APP2COMBIN1.ParentStyleUsing.UseFont = false;
            this.APP2COMBIN1.ParentStyleUsing.UseForeColor = false;
            this.APP2COMBIN1.Size = new System.Drawing.Size(79, 12);
            // 
            // APP3COMBIN1
            // 
            this.APP3COMBIN1.BackColor = System.Drawing.Color.White;
            this.APP3COMBIN1.BorderColor = System.Drawing.Color.Black;
            this.APP3COMBIN1.CanGrow = false;
            this.APP3COMBIN1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.APP3_COMBIN", "")});
            this.APP3COMBIN1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.APP3COMBIN1.ForeColor = System.Drawing.Color.Black;
            this.APP3COMBIN1.Location = new System.Drawing.Point(232, 0);
            this.APP3COMBIN1.Name = "APP3COMBIN1";
            this.APP3COMBIN1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.APP3COMBIN1.ParentStyleUsing.UseBackColor = false;
            this.APP3COMBIN1.ParentStyleUsing.UseBorderColor = false;
            this.APP3COMBIN1.ParentStyleUsing.UseBorders = false;
            this.APP3COMBIN1.ParentStyleUsing.UseBorderWidth = false;
            this.APP3COMBIN1.ParentStyleUsing.UseFont = false;
            this.APP3COMBIN1.ParentStyleUsing.UseForeColor = false;
            this.APP3COMBIN1.Size = new System.Drawing.Size(78, 12);
            // 
            // CLASS11
            // 
            this.CLASS11.BackColor = System.Drawing.Color.White;
            this.CLASS11.BorderColor = System.Drawing.Color.Black;
            this.CLASS11.CanGrow = false;
            this.CLASS11.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.CLASS1", "")});
            this.CLASS11.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CLASS11.ForeColor = System.Drawing.Color.Black;
            this.CLASS11.Location = new System.Drawing.Point(310, 0);
            this.CLASS11.Name = "CLASS11";
            this.CLASS11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CLASS11.ParentStyleUsing.UseBackColor = false;
            this.CLASS11.ParentStyleUsing.UseBorderColor = false;
            this.CLASS11.ParentStyleUsing.UseBorders = false;
            this.CLASS11.ParentStyleUsing.UseBorderWidth = false;
            this.CLASS11.ParentStyleUsing.UseFont = false;
            this.CLASS11.ParentStyleUsing.UseForeColor = false;
            this.CLASS11.Size = new System.Drawing.Size(33, 12);
            this.CLASS11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // CLASS21
            // 
            this.CLASS21.BackColor = System.Drawing.Color.White;
            this.CLASS21.BorderColor = System.Drawing.Color.Black;
            this.CLASS21.CanGrow = false;
            this.CLASS21.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.CLASS2", "")});
            this.CLASS21.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CLASS21.ForeColor = System.Drawing.Color.Black;
            this.CLASS21.Location = new System.Drawing.Point(344, 0);
            this.CLASS21.Name = "CLASS21";
            this.CLASS21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CLASS21.ParentStyleUsing.UseBackColor = false;
            this.CLASS21.ParentStyleUsing.UseBorderColor = false;
            this.CLASS21.ParentStyleUsing.UseBorders = false;
            this.CLASS21.ParentStyleUsing.UseBorderWidth = false;
            this.CLASS21.ParentStyleUsing.UseFont = false;
            this.CLASS21.ParentStyleUsing.UseForeColor = false;
            this.CLASS21.Size = new System.Drawing.Size(33, 12);
            this.CLASS21.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // CLASS31
            // 
            this.CLASS31.BackColor = System.Drawing.Color.White;
            this.CLASS31.BorderColor = System.Drawing.Color.Black;
            this.CLASS31.CanGrow = false;
            this.CLASS31.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.CLASS3", "")});
            this.CLASS31.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CLASS31.ForeColor = System.Drawing.Color.Black;
            this.CLASS31.Location = new System.Drawing.Point(378, 0);
            this.CLASS31.Name = "CLASS31";
            this.CLASS31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CLASS31.ParentStyleUsing.UseBackColor = false;
            this.CLASS31.ParentStyleUsing.UseBorderColor = false;
            this.CLASS31.ParentStyleUsing.UseBorders = false;
            this.CLASS31.ParentStyleUsing.UseBorderWidth = false;
            this.CLASS31.ParentStyleUsing.UseFont = false;
            this.CLASS31.ParentStyleUsing.UseForeColor = false;
            this.CLASS31.Size = new System.Drawing.Size(33, 12);
            this.CLASS31.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // CLASS51
            // 
            this.CLASS51.BackColor = System.Drawing.Color.White;
            this.CLASS51.BorderColor = System.Drawing.Color.Black;
            this.CLASS51.CanGrow = false;
            this.CLASS51.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.CLASS5", "")});
            this.CLASS51.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CLASS51.ForeColor = System.Drawing.Color.Black;
            this.CLASS51.Location = new System.Drawing.Point(444, 0);
            this.CLASS51.Name = "CLASS51";
            this.CLASS51.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CLASS51.ParentStyleUsing.UseBackColor = false;
            this.CLASS51.ParentStyleUsing.UseBorderColor = false;
            this.CLASS51.ParentStyleUsing.UseBorders = false;
            this.CLASS51.ParentStyleUsing.UseBorderWidth = false;
            this.CLASS51.ParentStyleUsing.UseFont = false;
            this.CLASS51.ParentStyleUsing.UseForeColor = false;
            this.CLASS51.Size = new System.Drawing.Size(32, 12);
            this.CLASS51.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // DESC1
            // 
            this.DESC1.BackColor = System.Drawing.Color.White;
            this.DESC1.BorderColor = System.Drawing.Color.Black;
            this.DESC1.CanGrow = false;
            this.DESC1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.DESC", "")});
            this.DESC1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DESC1.ForeColor = System.Drawing.Color.Black;
            this.DESC1.Location = new System.Drawing.Point(508, 0);
            this.DESC1.Name = "DESC1";
            this.DESC1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DESC1.ParentStyleUsing.UseBackColor = false;
            this.DESC1.ParentStyleUsing.UseBorderColor = false;
            this.DESC1.ParentStyleUsing.UseBorders = false;
            this.DESC1.ParentStyleUsing.UseBorderWidth = false;
            this.DESC1.ParentStyleUsing.UseFont = false;
            this.DESC1.ParentStyleUsing.UseForeColor = false;
            this.DESC1.Size = new System.Drawing.Size(150, 12);
            // 
            // MAINUNIT1
            // 
            this.MAINUNIT1.BackColor = System.Drawing.Color.White;
            this.MAINUNIT1.BorderColor = System.Drawing.Color.Black;
            this.MAINUNIT1.CanGrow = false;
            this.MAINUNIT1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.MAINUNIT", "")});
            this.MAINUNIT1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.MAINUNIT1.ForeColor = System.Drawing.Color.Black;
            this.MAINUNIT1.Location = new System.Drawing.Point(658, 0);
            this.MAINUNIT1.Name = "MAINUNIT1";
            this.MAINUNIT1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.MAINUNIT1.ParentStyleUsing.UseBackColor = false;
            this.MAINUNIT1.ParentStyleUsing.UseBorderColor = false;
            this.MAINUNIT1.ParentStyleUsing.UseBorders = false;
            this.MAINUNIT1.ParentStyleUsing.UseBorderWidth = false;
            this.MAINUNIT1.ParentStyleUsing.UseFont = false;
            this.MAINUNIT1.ParentStyleUsing.UseForeColor = false;
            this.MAINUNIT1.Size = new System.Drawing.Size(34, 12);
            this.MAINUNIT1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // DATECREATE1
            // 
            this.DATECREATE1.BackColor = System.Drawing.Color.White;
            this.DATECREATE1.BorderColor = System.Drawing.Color.Black;
            this.DATECREATE1.CanGrow = false;
            this.DATECREATE1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.DATECREATE", "")});
            this.DATECREATE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATECREATE1.ForeColor = System.Drawing.Color.Black;
            this.DATECREATE1.Location = new System.Drawing.Point(692, 0);
            this.DATECREATE1.Name = "DATECREATE1";
            this.DATECREATE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATECREATE1.ParentStyleUsing.UseBackColor = false;
            this.DATECREATE1.ParentStyleUsing.UseBorderColor = false;
            this.DATECREATE1.ParentStyleUsing.UseBorders = false;
            this.DATECREATE1.ParentStyleUsing.UseBorderWidth = false;
            this.DATECREATE1.ParentStyleUsing.UseFont = false;
            this.DATECREATE1.ParentStyleUsing.UseForeColor = false;
            this.DATECREATE1.Size = new System.Drawing.Size(54, 12);
            this.DATECREATE1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // CLASS41
            // 
            this.CLASS41.BackColor = System.Drawing.Color.White;
            this.CLASS41.BorderColor = System.Drawing.Color.Black;
            this.CLASS41.CanGrow = false;
            this.CLASS41.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.CLASS4", "")});
            this.CLASS41.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CLASS41.ForeColor = System.Drawing.Color.Black;
            this.CLASS41.Location = new System.Drawing.Point(411, 0);
            this.CLASS41.Name = "CLASS41";
            this.CLASS41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CLASS41.ParentStyleUsing.UseBackColor = false;
            this.CLASS41.ParentStyleUsing.UseBorderColor = false;
            this.CLASS41.ParentStyleUsing.UseBorders = false;
            this.CLASS41.ParentStyleUsing.UseBorderWidth = false;
            this.CLASS41.ParentStyleUsing.UseFont = false;
            this.CLASS41.ParentStyleUsing.UseForeColor = false;
            this.CLASS41.Size = new System.Drawing.Size(33, 12);
            this.CLASS41.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // CLASS61
            // 
            this.CLASS61.BackColor = System.Drawing.Color.White;
            this.CLASS61.BorderColor = System.Drawing.Color.Black;
            this.CLASS61.CanGrow = false;
            this.CLASS61.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.CLASS6", "")});
            this.CLASS61.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CLASS61.ForeColor = System.Drawing.Color.Black;
            this.CLASS61.Location = new System.Drawing.Point(476, 0);
            this.CLASS61.Name = "CLASS61";
            this.CLASS61.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CLASS61.ParentStyleUsing.UseBackColor = false;
            this.CLASS61.ParentStyleUsing.UseBorderColor = false;
            this.CLASS61.ParentStyleUsing.UseBorders = false;
            this.CLASS61.ParentStyleUsing.UseBorderWidth = false;
            this.CLASS61.ParentStyleUsing.UseFont = false;
            this.CLASS61.ParentStyleUsing.UseForeColor = false;
            this.CLASS61.Size = new System.Drawing.Size(32, 12);
            this.CLASS61.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // BASPRC1
            // 
            this.BASPRC1.BackColor = System.Drawing.Color.White;
            this.BASPRC1.BorderColor = System.Drawing.Color.Black;
            this.BASPRC1.CanGrow = false;
            this.BASPRC1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.BASPRC", "")});
            this.BASPRC1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.BASPRC1.ForeColor = System.Drawing.Color.Black;
            this.BASPRC1.Location = new System.Drawing.Point(152, 12);
            this.BASPRC1.Name = "BASPRC1";
            this.BASPRC1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.BASPRC1.ParentStyleUsing.UseBackColor = false;
            this.BASPRC1.ParentStyleUsing.UseBorderColor = false;
            this.BASPRC1.ParentStyleUsing.UseBorders = false;
            this.BASPRC1.ParentStyleUsing.UseBorderWidth = false;
            this.BASPRC1.ParentStyleUsing.UseFont = false;
            this.BASPRC1.ParentStyleUsing.UseForeColor = false;
            this.BASPRC1.Size = new System.Drawing.Size(79, 12);
            // 
            // WHLPRC1
            // 
            this.WHLPRC1.BackColor = System.Drawing.Color.White;
            this.WHLPRC1.BorderColor = System.Drawing.Color.Black;
            this.WHLPRC1.CanGrow = false;
            this.WHLPRC1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.WHLPRC", "")});
            this.WHLPRC1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.WHLPRC1.ForeColor = System.Drawing.Color.Black;
            this.WHLPRC1.Location = new System.Drawing.Point(348, 12);
            this.WHLPRC1.Name = "WHLPRC1";
            this.WHLPRC1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.WHLPRC1.ParentStyleUsing.UseBackColor = false;
            this.WHLPRC1.ParentStyleUsing.UseBorderColor = false;
            this.WHLPRC1.ParentStyleUsing.UseBorders = false;
            this.WHLPRC1.ParentStyleUsing.UseBorderWidth = false;
            this.WHLPRC1.ParentStyleUsing.UseFont = false;
            this.WHLPRC1.ParentStyleUsing.UseForeColor = false;
            this.WHLPRC1.Size = new System.Drawing.Size(62, 12);
            // 
            // VCURR1
            // 
            this.VCURR1.BackColor = System.Drawing.Color.White;
            this.VCURR1.BorderColor = System.Drawing.Color.Black;
            this.VCURR1.CanGrow = false;
            this.VCURR1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.VCURR", "")});
            this.VCURR1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.VCURR1.ForeColor = System.Drawing.Color.Black;
            this.VCURR1.Location = new System.Drawing.Point(508, 12);
            this.VCURR1.Name = "VCURR1";
            this.VCURR1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.VCURR1.ParentStyleUsing.UseBackColor = false;
            this.VCURR1.ParentStyleUsing.UseBorderColor = false;
            this.VCURR1.ParentStyleUsing.UseBorders = false;
            this.VCURR1.ParentStyleUsing.UseBorderWidth = false;
            this.VCURR1.ParentStyleUsing.UseFont = false;
            this.VCURR1.ParentStyleUsing.UseForeColor = false;
            this.VCURR1.Size = new System.Drawing.Size(32, 12);
            // 
            // VPRC1
            // 
            this.VPRC1.BackColor = System.Drawing.Color.White;
            this.VPRC1.BorderColor = System.Drawing.Color.Black;
            this.VPRC1.CanGrow = false;
            this.VPRC1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.VPRC", "")});
            this.VPRC1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.VPRC1.ForeColor = System.Drawing.Color.Black;
            this.VPRC1.Location = new System.Drawing.Point(542, 12);
            this.VPRC1.Name = "VPRC1";
            this.VPRC1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.VPRC1.ParentStyleUsing.UseBackColor = false;
            this.VPRC1.ParentStyleUsing.UseBorderColor = false;
            this.VPRC1.ParentStyleUsing.UseBorders = false;
            this.VPRC1.ParentStyleUsing.UseBorderWidth = false;
            this.VPRC1.ParentStyleUsing.UseFont = false;
            this.VPRC1.ParentStyleUsing.UseForeColor = false;
            this.VPRC1.Size = new System.Drawing.Size(50, 12);
            // 
            // Text38
            // 
            this.Text38.BackColor = System.Drawing.Color.White;
            this.Text38.BorderColor = System.Drawing.Color.Black;
            this.Text38.CanGrow = false;
            this.Text38.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text38.ForeColor = System.Drawing.Color.Black;
            this.Text38.Location = new System.Drawing.Point(73, 12);
            this.Text38.Name = "Text38";
            this.Text38.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text38.ParentStyleUsing.UseBackColor = false;
            this.Text38.ParentStyleUsing.UseBorderColor = false;
            this.Text38.ParentStyleUsing.UseBorders = false;
            this.Text38.ParentStyleUsing.UseBorderWidth = false;
            this.Text38.ParentStyleUsing.UseFont = false;
            this.Text38.ParentStyleUsing.UseForeColor = false;
            this.Text38.Size = new System.Drawing.Size(79, 12);
            this.Text38.Text = "Basic Price:";
            // 
            // Text39
            // 
            this.Text39.BackColor = System.Drawing.Color.White;
            this.Text39.BorderColor = System.Drawing.Color.Black;
            this.Text39.CanGrow = false;
            this.Text39.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text39.ForeColor = System.Drawing.Color.Black;
            this.Text39.Location = new System.Drawing.Point(252, 12);
            this.Text39.Name = "Text39";
            this.Text39.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text39.ParentStyleUsing.UseBackColor = false;
            this.Text39.ParentStyleUsing.UseBorderColor = false;
            this.Text39.ParentStyleUsing.UseBorders = false;
            this.Text39.ParentStyleUsing.UseBorderWidth = false;
            this.Text39.ParentStyleUsing.UseFont = false;
            this.Text39.ParentStyleUsing.UseForeColor = false;
            this.Text39.Size = new System.Drawing.Size(92, 12);
            this.Text39.Text = "Whole Price : ";
            this.Text39.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text40
            // 
            this.Text40.BackColor = System.Drawing.Color.White;
            this.Text40.BorderColor = System.Drawing.Color.Black;
            this.Text40.CanGrow = false;
            this.Text40.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text40.ForeColor = System.Drawing.Color.Black;
            this.Text40.Location = new System.Drawing.Point(444, 12);
            this.Text40.Name = "Text40";
            this.Text40.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text40.ParentStyleUsing.UseBackColor = false;
            this.Text40.ParentStyleUsing.UseBorderColor = false;
            this.Text40.ParentStyleUsing.UseBorders = false;
            this.Text40.ParentStyleUsing.UseBorderWidth = false;
            this.Text40.ParentStyleUsing.UseFont = false;
            this.Text40.ParentStyleUsing.UseForeColor = false;
            this.Text40.Size = new System.Drawing.Size(64, 12);
            this.Text40.Text = "VCurr : ";
            // 
            // Text41
            // 
            this.Text41.BackColor = System.Drawing.Color.White;
            this.Text41.BorderColor = System.Drawing.Color.Black;
            this.Text41.CanGrow = false;
            this.Text41.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text41.ForeColor = System.Drawing.Color.Black;
            this.Text41.Location = new System.Drawing.Point(625, 12);
            this.Text41.Name = "Text41";
            this.Text41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text41.ParentStyleUsing.UseBackColor = false;
            this.Text41.ParentStyleUsing.UseBorderColor = false;
            this.Text41.ParentStyleUsing.UseBorders = false;
            this.Text41.ParentStyleUsing.UseBorderWidth = false;
            this.Text41.ParentStyleUsing.UseFont = false;
            this.Text41.ParentStyleUsing.UseForeColor = false;
            this.Text41.Size = new System.Drawing.Size(67, 12);
            this.Text41.Text = "Status : ";
            this.Text41.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // StatusP1
            // 
            this.StatusP1.BackColor = System.Drawing.Color.White;
            this.StatusP1.BorderColor = System.Drawing.Color.Black;
            this.StatusP1.CanGrow = false;
            this.StatusP1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.StatusP1.ForeColor = System.Drawing.Color.Black;
            this.StatusP1.Location = new System.Drawing.Point(692, 12);
            this.StatusP1.Name = "StatusP1";
            this.StatusP1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.StatusP1.ParentStyleUsing.UseBackColor = false;
            this.StatusP1.ParentStyleUsing.UseBorderColor = false;
            this.StatusP1.ParentStyleUsing.UseBorders = false;
            this.StatusP1.ParentStyleUsing.UseBorderWidth = false;
            this.StatusP1.ParentStyleUsing.UseFont = false;
            this.StatusP1.ParentStyleUsing.UseForeColor = false;
            this.StatusP1.Size = new System.Drawing.Size(54, 12);
            this.StatusP1.Text = "Untranslated";
            // 
            // APP1COMBIN1
            // 
            this.APP1COMBIN1.BackColor = System.Drawing.Color.White;
            this.APP1COMBIN1.BorderColor = System.Drawing.Color.Black;
            this.APP1COMBIN1.CanGrow = false;
            this.APP1COMBIN1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblStockBatch.APP1_COMBIN", "")});
            this.APP1COMBIN1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.APP1COMBIN1.ForeColor = System.Drawing.Color.Black;
            this.APP1COMBIN1.Location = new System.Drawing.Point(73, 0);
            this.APP1COMBIN1.Name = "APP1COMBIN1";
            this.APP1COMBIN1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.APP1COMBIN1.ParentStyleUsing.UseBackColor = false;
            this.APP1COMBIN1.ParentStyleUsing.UseBorderColor = false;
            this.APP1COMBIN1.ParentStyleUsing.UseBorders = false;
            this.APP1COMBIN1.ParentStyleUsing.UseBorderWidth = false;
            this.APP1COMBIN1.ParentStyleUsing.UseFont = false;
            this.APP1COMBIN1.ParentStyleUsing.UseForeColor = false;
            this.APP1COMBIN1.Size = new System.Drawing.Size(79, 12);
            // 
            // ReportFooter
            // 
            this.ReportFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Line2,
            this.endofreport1});
            this.ReportFooter.Height = 34;
            this.ReportFooter.Name = "ReportFooter";
            // 
            // endofreport1
            // 
            this.endofreport1.BackColor = System.Drawing.Color.White;
            this.endofreport1.BorderColor = System.Drawing.Color.Black;
            this.endofreport1.CanGrow = false;
            this.endofreport1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.endofreport1.ForeColor = System.Drawing.Color.Black;
            this.endofreport1.Location = new System.Drawing.Point(0, 17);
            this.endofreport1.Name = "endofreport1";
            this.endofreport1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.endofreport1.ParentStyleUsing.UseBackColor = false;
            this.endofreport1.ParentStyleUsing.UseBorderColor = false;
            this.endofreport1.ParentStyleUsing.UseBorders = false;
            this.endofreport1.ParentStyleUsing.UseBorderWidth = false;
            this.endofreport1.ParentStyleUsing.UseFont = false;
            this.endofreport1.ParentStyleUsing.UseForeColor = false;
            this.endofreport1.Size = new System.Drawing.Size(204, 15);
            this.endofreport1.Text = "Untranslated";
            // 
            // Line2
            // 
            this.Line2.BackColor = System.Drawing.Color.White;
            this.Line2.BorderColor = System.Drawing.Color.Black;
            this.Line2.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.Line2.CanGrow = false;
            this.Line2.ForeColor = System.Drawing.Color.Black;
            this.Line2.Location = new System.Drawing.Point(0, 0);
            this.Line2.Name = "Line2";
            this.Line2.ParentStyleUsing.UseBackColor = false;
            this.Line2.ParentStyleUsing.UseBorderColor = false;
            this.Line2.ParentStyleUsing.UseBorders = false;
            this.Line2.ParentStyleUsing.UseBorderWidth = false;
            this.Line2.ParentStyleUsing.UseFont = false;
            this.Line2.ParentStyleUsing.UseForeColor = false;
            this.Line2.Size = new System.Drawing.Size(798, 2);
            // 
            // PageFooter
            // 
            this.PageFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Class62,
            this.Class52,
            this.Class42,
            this.Class32,
            this.Class22,
            this.Class12,
            this.Text57,
            this.Text56,
            this.Text55,
            this.Text54,
            this.Text53,
            this.Text52});
            this.PageFooter.Height = 16;
            this.PageFooter.Name = "PageFooter";
            // 
            // Text52
            // 
            this.Text52.BackColor = System.Drawing.Color.White;
            this.Text52.BorderColor = System.Drawing.Color.Black;
            this.Text52.CanGrow = false;
            this.Text52.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text52.ForeColor = System.Drawing.Color.Black;
            this.Text52.Location = new System.Drawing.Point(0, 0);
            this.Text52.Name = "Text52";
            this.Text52.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text52.ParentStyleUsing.UseBackColor = false;
            this.Text52.ParentStyleUsing.UseBorderColor = false;
            this.Text52.ParentStyleUsing.UseBorders = false;
            this.Text52.ParentStyleUsing.UseBorderWidth = false;
            this.Text52.ParentStyleUsing.UseFont = false;
            this.Text52.ParentStyleUsing.UseForeColor = false;
            this.Text52.Size = new System.Drawing.Size(29, 14);
            this.Text52.Text = "C1:";
            // 
            // Text53
            // 
            this.Text53.BackColor = System.Drawing.Color.White;
            this.Text53.BorderColor = System.Drawing.Color.Black;
            this.Text53.CanGrow = false;
            this.Text53.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text53.ForeColor = System.Drawing.Color.Black;
            this.Text53.Location = new System.Drawing.Point(125, 0);
            this.Text53.Name = "Text53";
            this.Text53.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text53.ParentStyleUsing.UseBackColor = false;
            this.Text53.ParentStyleUsing.UseBorderColor = false;
            this.Text53.ParentStyleUsing.UseBorders = false;
            this.Text53.ParentStyleUsing.UseBorderWidth = false;
            this.Text53.ParentStyleUsing.UseFont = false;
            this.Text53.ParentStyleUsing.UseForeColor = false;
            this.Text53.Size = new System.Drawing.Size(28, 15);
            this.Text53.Text = "C2:";
            // 
            // Text54
            // 
            this.Text54.BackColor = System.Drawing.Color.White;
            this.Text54.BorderColor = System.Drawing.Color.Black;
            this.Text54.CanGrow = false;
            this.Text54.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text54.ForeColor = System.Drawing.Color.Black;
            this.Text54.Location = new System.Drawing.Point(232, 0);
            this.Text54.Name = "Text54";
            this.Text54.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text54.ParentStyleUsing.UseBackColor = false;
            this.Text54.ParentStyleUsing.UseBorderColor = false;
            this.Text54.ParentStyleUsing.UseBorders = false;
            this.Text54.ParentStyleUsing.UseBorderWidth = false;
            this.Text54.ParentStyleUsing.UseFont = false;
            this.Text54.ParentStyleUsing.UseForeColor = false;
            this.Text54.Size = new System.Drawing.Size(29, 15);
            this.Text54.Text = "C3:";
            // 
            // Text55
            // 
            this.Text55.BackColor = System.Drawing.Color.White;
            this.Text55.BorderColor = System.Drawing.Color.Black;
            this.Text55.CanGrow = false;
            this.Text55.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text55.ForeColor = System.Drawing.Color.Black;
            this.Text55.Location = new System.Drawing.Point(350, 0);
            this.Text55.Name = "Text55";
            this.Text55.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text55.ParentStyleUsing.UseBackColor = false;
            this.Text55.ParentStyleUsing.UseBorderColor = false;
            this.Text55.ParentStyleUsing.UseBorders = false;
            this.Text55.ParentStyleUsing.UseBorderWidth = false;
            this.Text55.ParentStyleUsing.UseFont = false;
            this.Text55.ParentStyleUsing.UseForeColor = false;
            this.Text55.Size = new System.Drawing.Size(27, 15);
            this.Text55.Text = "C4:";
            // 
            // Text56
            // 
            this.Text56.BackColor = System.Drawing.Color.White;
            this.Text56.BorderColor = System.Drawing.Color.Black;
            this.Text56.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text56.ForeColor = System.Drawing.Color.Black;
            this.Text56.Location = new System.Drawing.Point(462, 0);
            this.Text56.Name = "Text56";
            this.Text56.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text56.ParentStyleUsing.UseBackColor = false;
            this.Text56.ParentStyleUsing.UseBorderColor = false;
            this.Text56.ParentStyleUsing.UseBorders = false;
            this.Text56.ParentStyleUsing.UseBorderWidth = false;
            this.Text56.ParentStyleUsing.UseFont = false;
            this.Text56.ParentStyleUsing.UseForeColor = false;
            this.Text56.Size = new System.Drawing.Size(27, 15);
            this.Text56.Text = "C5:";
            // 
            // Text57
            // 
            this.Text57.BackColor = System.Drawing.Color.White;
            this.Text57.BorderColor = System.Drawing.Color.Black;
            this.Text57.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text57.ForeColor = System.Drawing.Color.Black;
            this.Text57.Location = new System.Drawing.Point(575, 0);
            this.Text57.Name = "Text57";
            this.Text57.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text57.ParentStyleUsing.UseBackColor = false;
            this.Text57.ParentStyleUsing.UseBorderColor = false;
            this.Text57.ParentStyleUsing.UseBorders = false;
            this.Text57.ParentStyleUsing.UseBorderWidth = false;
            this.Text57.ParentStyleUsing.UseFont = false;
            this.Text57.ParentStyleUsing.UseForeColor = false;
            this.Text57.Size = new System.Drawing.Size(25, 15);
            this.Text57.Text = "C6:";
            // 
            // Class12
            // 
            this.Class12.BackColor = System.Drawing.Color.White;
            this.Class12.BorderColor = System.Drawing.Color.Black;
            this.Class12.CanGrow = false;
            this.Class12.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Class12.ForeColor = System.Drawing.Color.Black;
            this.Class12.Location = new System.Drawing.Point(32, 0);
            this.Class12.Name = "Class12";
            this.Class12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class12.ParentStyleUsing.UseBackColor = false;
            this.Class12.ParentStyleUsing.UseBorderColor = false;
            this.Class12.ParentStyleUsing.UseBorders = false;
            this.Class12.ParentStyleUsing.UseBorderWidth = false;
            this.Class12.ParentStyleUsing.UseFont = false;
            this.Class12.ParentStyleUsing.UseForeColor = false;
            this.Class12.Size = new System.Drawing.Size(82, 14);
            this.Class12.Text = "Untranslated";
            // 
            // Class22
            // 
            this.Class22.BackColor = System.Drawing.Color.White;
            this.Class22.BorderColor = System.Drawing.Color.Black;
            this.Class22.CanGrow = false;
            this.Class22.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Class22.ForeColor = System.Drawing.Color.Black;
            this.Class22.Location = new System.Drawing.Point(153, 0);
            this.Class22.Name = "Class22";
            this.Class22.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class22.ParentStyleUsing.UseBackColor = false;
            this.Class22.ParentStyleUsing.UseBorderColor = false;
            this.Class22.ParentStyleUsing.UseBorders = false;
            this.Class22.ParentStyleUsing.UseBorderWidth = false;
            this.Class22.ParentStyleUsing.UseFont = false;
            this.Class22.ParentStyleUsing.UseForeColor = false;
            this.Class22.Size = new System.Drawing.Size(79, 15);
            this.Class22.Text = "Untranslated";
            // 
            // Class32
            // 
            this.Class32.BackColor = System.Drawing.Color.White;
            this.Class32.BorderColor = System.Drawing.Color.Black;
            this.Class32.CanGrow = false;
            this.Class32.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Class32.ForeColor = System.Drawing.Color.Black;
            this.Class32.Location = new System.Drawing.Point(261, 0);
            this.Class32.Name = "Class32";
            this.Class32.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class32.ParentStyleUsing.UseBackColor = false;
            this.Class32.ParentStyleUsing.UseBorderColor = false;
            this.Class32.ParentStyleUsing.UseBorders = false;
            this.Class32.ParentStyleUsing.UseBorderWidth = false;
            this.Class32.ParentStyleUsing.UseFont = false;
            this.Class32.ParentStyleUsing.UseForeColor = false;
            this.Class32.Size = new System.Drawing.Size(71, 15);
            this.Class32.Text = "Untranslated";
            // 
            // Class42
            // 
            this.Class42.BackColor = System.Drawing.Color.White;
            this.Class42.BorderColor = System.Drawing.Color.Black;
            this.Class42.CanGrow = false;
            this.Class42.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Class42.ForeColor = System.Drawing.Color.Black;
            this.Class42.Location = new System.Drawing.Point(378, 0);
            this.Class42.Name = "Class42";
            this.Class42.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class42.ParentStyleUsing.UseBackColor = false;
            this.Class42.ParentStyleUsing.UseBorderColor = false;
            this.Class42.ParentStyleUsing.UseBorders = false;
            this.Class42.ParentStyleUsing.UseBorderWidth = false;
            this.Class42.ParentStyleUsing.UseFont = false;
            this.Class42.ParentStyleUsing.UseForeColor = false;
            this.Class42.Size = new System.Drawing.Size(75, 14);
            this.Class42.Text = "Untranslated";
            // 
            // Class52
            // 
            this.Class52.BackColor = System.Drawing.Color.White;
            this.Class52.BorderColor = System.Drawing.Color.Black;
            this.Class52.CanGrow = false;
            this.Class52.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Class52.ForeColor = System.Drawing.Color.Black;
            this.Class52.Location = new System.Drawing.Point(489, 0);
            this.Class52.Name = "Class52";
            this.Class52.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class52.ParentStyleUsing.UseBackColor = false;
            this.Class52.ParentStyleUsing.UseBorderColor = false;
            this.Class52.ParentStyleUsing.UseBorders = false;
            this.Class52.ParentStyleUsing.UseBorderWidth = false;
            this.Class52.ParentStyleUsing.UseFont = false;
            this.Class52.ParentStyleUsing.UseForeColor = false;
            this.Class52.Size = new System.Drawing.Size(76, 15);
            this.Class52.Text = "Untranslated";
            // 
            // Class62
            // 
            this.Class62.BackColor = System.Drawing.Color.White;
            this.Class62.BorderColor = System.Drawing.Color.Black;
            this.Class62.CanGrow = false;
            this.Class62.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Class62.ForeColor = System.Drawing.Color.Black;
            this.Class62.Location = new System.Drawing.Point(600, 0);
            this.Class62.Name = "Class62";
            this.Class62.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class62.ParentStyleUsing.UseBackColor = false;
            this.Class62.ParentStyleUsing.UseBorderColor = false;
            this.Class62.ParentStyleUsing.UseBorders = false;
            this.Class62.ParentStyleUsing.UseBorderWidth = false;
            this.Class62.ParentStyleUsing.UseFont = false;
            this.Class62.ParentStyleUsing.UseForeColor = false;
            this.Class62.Size = new System.Drawing.Size(86, 15);
            this.Class62.Text = "Untranslated";
            // 
            // CM1520c
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.GroupHeader1,
            this.GroupFooter1,
            this.ReportHeader,
            this.PageHeader,
            this.ReportFooter,
            this.PageFooter});
            this.DataAdapter = this.oleDbDataAdapter1;
            this.Margins = new System.Drawing.Printing.Margins(39, 39, 19, 19);
            this.PageHeight = 1168;
            this.PageWidth = 825;
            this.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.XRLabel APP1COMBIN1;
        private DevExpress.XtraReports.UI.XRLabel StatusP1;
        private DevExpress.XtraReports.UI.XRLabel Text41;
        private DevExpress.XtraReports.UI.XRLabel Text40;
        private DevExpress.XtraReports.UI.XRLabel Text39;
        private DevExpress.XtraReports.UI.XRLabel Text38;
        private DevExpress.XtraReports.UI.XRLabel VPRC1;
        private DevExpress.XtraReports.UI.XRLabel VCURR1;
        private DevExpress.XtraReports.UI.XRLabel WHLPRC1;
        private DevExpress.XtraReports.UI.XRLabel BASPRC1;
        private DevExpress.XtraReports.UI.XRLabel CLASS61;
        private DevExpress.XtraReports.UI.XRLabel CLASS41;
        private DevExpress.XtraReports.UI.XRLabel DATECREATE1;
        private DevExpress.XtraReports.UI.XRLabel MAINUNIT1;
        private DevExpress.XtraReports.UI.XRLabel DESC1;
        private DevExpress.XtraReports.UI.XRLabel CLASS51;
        private DevExpress.XtraReports.UI.XRLabel CLASS31;
        private DevExpress.XtraReports.UI.XRLabel CLASS21;
        private DevExpress.XtraReports.UI.XRLabel CLASS11;
        private DevExpress.XtraReports.UI.XRLabel APP3COMBIN1;
        private DevExpress.XtraReports.UI.XRLabel APP2COMBIN1;
        private DevExpress.XtraReports.UI.XRLabel STKCODE1;
        private System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
        private System.Data.OleDb.OleDbCommand oleDbCommand1;
        private System.Data.OleDb.OleDbConnection oleDbConnection1;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader1;
        private DevExpress.XtraReports.UI.GroupFooterBand GroupFooter1;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        private DevExpress.XtraReports.UI.XRLabel hdrCompName1;
        private DevExpress.XtraReports.UI.XRLabel PrintTime1;
        private DevExpress.XtraReports.UI.XRLabel hdrStkCode1;
        private DevExpress.XtraReports.UI.XRLine Line1;
        private DevExpress.XtraReports.UI.XRLabel App3c1;
        private DevExpress.XtraReports.UI.XRLabel App2C1;
        private DevExpress.XtraReports.UI.XRLabel App1C1;
        private DevExpress.XtraReports.UI.XRLabel Text15;
        private DevExpress.XtraReports.UI.XRLabel Text14;
        private DevExpress.XtraReports.UI.XRLabel Text13;
        private DevExpress.XtraReports.UI.XRLabel Text11;
        private DevExpress.XtraReports.UI.XRLabel Text10;
        private DevExpress.XtraReports.UI.XRLabel Text9;
        private DevExpress.XtraReports.UI.XRLabel Text8;
        private DevExpress.XtraReports.UI.XRLabel Text7;
        private DevExpress.XtraReports.UI.XRLabel Text6;
        private DevExpress.XtraReports.UI.XRLabel TotalPageCount1;
        private DevExpress.XtraReports.UI.XRPageInfo PageNumber1;
        private DevExpress.XtraReports.UI.XRLabel Text5;
        private DevExpress.XtraReports.UI.XRLabel Text4;
        private DevExpress.XtraReports.UI.XRLabel PrintDate1;
        private DevExpress.XtraReports.UI.XRLabel Text3;
        private DevExpress.XtraReports.UI.XRLabel Text2;
        private DevExpress.XtraReports.UI.XRLabel Text1;
        private DevExpress.XtraReports.UI.XRLabel Text12;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.ReportFooterBand ReportFooter;
        private DevExpress.XtraReports.UI.XRLine Line2;
        private DevExpress.XtraReports.UI.XRLabel endofreport1;
        private DevExpress.XtraReports.UI.PageFooterBand PageFooter;
        private DevExpress.XtraReports.UI.XRLabel Class62;
        private DevExpress.XtraReports.UI.XRLabel Class52;
        private DevExpress.XtraReports.UI.XRLabel Class42;
        private DevExpress.XtraReports.UI.XRLabel Class32;
        private DevExpress.XtraReports.UI.XRLabel Class22;
        private DevExpress.XtraReports.UI.XRLabel Class12;
        private DevExpress.XtraReports.UI.XRLabel Text57;
        private DevExpress.XtraReports.UI.XRLabel Text56;
        private DevExpress.XtraReports.UI.XRLabel Text55;
        private DevExpress.XtraReports.UI.XRLabel Text54;
        private DevExpress.XtraReports.UI.XRLabel Text53;
        private DevExpress.XtraReports.UI.XRLabel Text52;

    }
}
